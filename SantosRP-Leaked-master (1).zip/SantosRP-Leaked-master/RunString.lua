surface.PlaySound( "garrysmod/ui_hover.wav" )
-----------------------------------------------------
RunGameUICommand( 'engine disconnect' )