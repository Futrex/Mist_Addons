
-----------------------------------------------------
local Category = "Doctors NPC's"

local NPC = { 	Name = "Male 02", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_02_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp1000", NPC )

local NPC = { 	Name = "Male 04", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_04_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp2000", NPC )

local NPC = { 	Name = "Male 05", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_05_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp3000", NPC )

local NPC = { 	Name = "Male 06", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_06_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp4000", NPC )

local NPC = { 	Name = "Male 08", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_08_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp5000", NPC )

local NPC = { 	Name = "Male 09", 
				Class = "npc_citizen",
				Model = "models/humans/doctors/male_09_medic.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp6000", NPC )