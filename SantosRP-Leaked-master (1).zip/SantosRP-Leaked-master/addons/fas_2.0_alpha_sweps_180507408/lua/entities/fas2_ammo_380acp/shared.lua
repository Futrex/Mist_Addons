
-----------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = ".380 ACP Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Ammo"
ENT.AmmoType = ".380 ACP"
ENT.Amount = 60