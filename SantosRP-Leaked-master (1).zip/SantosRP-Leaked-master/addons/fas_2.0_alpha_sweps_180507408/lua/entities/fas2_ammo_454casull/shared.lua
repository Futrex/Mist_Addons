
-----------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = ".500 S&W Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Ammo"
ENT.AmmoType = ".454 Casull"
ENT.Amount = 10