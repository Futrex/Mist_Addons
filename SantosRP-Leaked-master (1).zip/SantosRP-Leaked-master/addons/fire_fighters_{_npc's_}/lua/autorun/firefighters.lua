
-----------------------------------------------------
local Category = "Fire Fighter NPC's"

local NPC = { 	Name = "Male 02", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_02_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp10", NPC )

local NPC = { 	Name = "Male 04", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_04_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp20", NPC )


local NPC = { 	Name = "Male 05", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_05_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp30", NPC )

local NPC = { 	Name = "Male 06", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_06_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp40", NPC )

local NPC = { 	Name = "Male 08", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_08_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp50", NPC )

local NPC = { 	Name = "Male 09", 
				Class = "npc_citizen",
				Model = "models/humans/firefighter/male_09_fireman.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp60", NPC )