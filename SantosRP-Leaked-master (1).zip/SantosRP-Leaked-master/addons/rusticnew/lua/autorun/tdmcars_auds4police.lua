
-----------------------------------------------------
local V = {
			Name = "Audi S4 Police", 
			Class = "prop_vehicle_jeep",
			Category = "TDM Emergency",
			Author = "TheDanishMaster, Turn 10",
			Information = "A drivable Audi S4 Police by TheDanishMaster",
				Model = "models/tdmcars/emergency/aud_s4_pred.mdl",
							KeyValues = {
							vehiclescript	=	"scripts/vehicles/TDMCars/aud_s4pol.txt"
							}
			}
list.Set("Vehicles", "audis4pol", V)