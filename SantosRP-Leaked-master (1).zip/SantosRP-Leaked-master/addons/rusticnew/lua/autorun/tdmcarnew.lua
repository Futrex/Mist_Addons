
-----------------------------------------------------
local V = {
			Name = "Audi Q7 Police", 
			Class = "prop_vehicle_jeep",
			Category = "RUSTIC NEWW",
			Author = "Sped_, Turn 10",
			Information = "A drivable BMW M5 F10 made by Turn 10 studio's and ported by Sped_",
			Model = "models/tdmcars/audi_q7_polchi_pr.mdl",
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/TDMCars/q7.txt"
							}
			}
list.Set("Vehicles", "audiq7police", V)