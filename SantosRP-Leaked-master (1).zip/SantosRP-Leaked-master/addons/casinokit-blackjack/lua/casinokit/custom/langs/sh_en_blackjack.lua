
-----------------------------------------------------
local a=CasinoKit.getLanguageObject("en")
a.cantaffordmin="you cannot afford paing the minimum bet at this table!"
a.blackjack_minimum="minimum"
a.blackjack_maximum="maximum"
a.blackjack_hit="hit"
a.blackjack_stand="stand"
a.blackjack_split="split"
a.blackjack_ddown="double down"
a.blackjack_insurance="insurance"
a.blackjack_evenmoney="even money"
a.blackjack_initBet="initial bets"
a.blackjack_initDeal="initial deal"
a.blackjack_playing="player action"
a.blackjack_reveal="dealer's hand reveal"
a.blackjack_showdown="bet settling"
a.blackjack_gameover="game over"
a.blackjack_insuranceplaced="You have already placed insurance!"
a.blackjack_alreadysplit="You have already split!"
a.blackjack_wonbet="You won your bet: %d"
a.blackjack_wonbetbj="You won your bet with a blackjack: %d"
a.blackjack_lostbet="You lost your bet: %d"
a.blackjack_pushbet="You tied. Pushing bet: %d"
a.blackjack_woninsurance="You won insurance bet: %d"
a.blackjack_lostinsurance="You lost insurance bet: %d"
a.blackjack_tookevenmoney="You took even money"