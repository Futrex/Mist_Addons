
-----------------------------------------------------
local PlayerCl = CasinoKit.class("PlayerCl")
