
-----------------------------------------------------
CasinoKit.tdui.RegisterSkin("CasinoKit", {
	rect = {
		color = Color(44, 62, 80, 200)
	},
	button = {
		bgColor = Color(44, 62, 80, 250),
		bgHoverColor = Color(192, 57, 43),
		fgColor = Color(255, 255, 255)
	}
})
