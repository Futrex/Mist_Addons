
-----------------------------------------------------
local V = {
			Name = "2011 Cadillac CTS-V Coupe", 
			Class = "prop_vehicle_jeep",
			Category = "RU Cars",
			Author = "SGM",
			Information = "A drivable 2011 Cadillac CTS-V Coupe",
				Model = "models/sentry/ctsv.mdl",
							KeyValues = {
							vehiclescript	=	"scripts/vehicles/TDMCars/cadillaccts.txt"
							}
			}
list.Set("Vehicles", "ctsv", V)

local V = {
			Name = "2011 Cadillac CTS-V Coupe Undercover", 
			Class = "prop_vehicle_jeep",
			Category = "RU Cars",
			Author = "SGM",
			Information = "A drivable 2011 Cadillac CTS-V Coupe",
				Model = "models/sentry/ctsv_uc.mdl",
							KeyValues = {
							vehiclescript	=	"scripts/vehicles/TDMCars/cadillacctsund.txt"
							}
			}
list.Set("Vehicles", "ctsvuv", V)