
-----------------------------------------------------
list.Set( "PlayerOptionsModel","Female_police01","models/portal/player/female_police02.mdl" )
player_manager.AddValidModel( "Female_police01","models/portal/player/female_police02.mdl" )


