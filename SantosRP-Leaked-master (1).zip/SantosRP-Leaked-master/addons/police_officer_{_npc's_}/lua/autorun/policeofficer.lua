
-----------------------------------------------------
local Category = "Police NPC's"

local NPC = { 	Name = "Male 02", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_02_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp1", NPC )

local NPC = { 	Name = "Male 04", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_04_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp2", NPC )


local NPC = { 	Name = "Male 05", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_05_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp3", NPC )

local NPC = { 	Name = "Male 06", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_06_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp4", NPC )

local NPC = { 	Name = "Male 08", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_08_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp5", NPC )

local NPC = { 	Name = "Male 09", 
				Class = "npc_citizen",
				Model = "models/humans/santosrp/male_09_santosrp.mdl",
				Health = "200",
				KeyValues = { citizentype = 4 },
				Category = Category	}

list.Set( "NPC", "npc_srp6", NPC )