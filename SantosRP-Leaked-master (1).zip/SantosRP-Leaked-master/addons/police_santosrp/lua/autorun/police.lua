
-----------------------------------------------------
player_manager.AddValidModel( "Police_1", "models/player/santosrp/Male_02_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_1", "models/player/santosrp/Male_02_santosrp.mdl" )

player_manager.AddValidModel( "Police_2", "models/player/santosrp/Male_04_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_2", "models/player/santosrp/Male_04_santosrp.mdl" )

player_manager.AddValidModel( "Police_3", "models/player/santosrp/Male_05_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_3", "models/player/santosrp/Male_05_santosrp.mdl" )

player_manager.AddValidModel( "Police_4", "models/player/santosrp/Male_06_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_4", "models/player/santosrp/Male_06_santosrp.mdl" )

player_manager.AddValidModel( "Police_5", "models/player/santosrp/Male_07_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_5", "models/player/santosrp/Male_07_santosrp.mdl" )

player_manager.AddValidModel( "Police_6", "models/player/santosrp/Male_08_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_6", "models/player/santosrp/Male_08_santosrp.mdl" )

player_manager.AddValidModel( "Police_7", "models/player/santosrp/Male_09_santosrp.mdl" )
list.Set( "PlayerOptionsModel", "Police_7", "models/player/santosrp/Male_09_santosrp.mdl" )
