
-----------------------------------------------------
local V = {
			Name = "Chevrolet Tahoe Secret Service", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable tahoe by LoneWolfie",
			Model = "models/LoneWolfie/chev_tahoe_police.mdl",
							
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/chev_tahoe.txt"
				    }
			}
list.Set("Vehicles", "chev_tahoe_police_lw", V)
