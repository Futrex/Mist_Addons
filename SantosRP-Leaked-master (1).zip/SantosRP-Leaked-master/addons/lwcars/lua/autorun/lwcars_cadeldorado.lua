
-----------------------------------------------------
local V = {
			Name = "Cadillac Eldorado Biarritz Convertible", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable Cadillac Eldorado Biarritz Convertible by LoneWolfie",
			Model = "models/LoneWolfie/cad_eldorado.mdl",										//Vehicle Controller

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/cad_eldorado.txt"
							}
			}
list.Set("Vehicles", "cad_eldorado", V)