
-----------------------------------------------------
local V = {
			Name = "Mercedes Sprinter Open Chassis", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable merc_sprinter_openchassis by LoneWolfie",
			Model = "models/LoneWolfie/merc_sprinter_openchassis.mdl",
	
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/merc_sprinter_swb.txt"
							}
			}
list.Set("Vehicles", "merc_sprinter_openchassis_lw", V)
