
-----------------------------------------------------
local V = {
			Name = "Subaru Legacy Outback", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/subaru_outback_zero.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/subaru_outback_zero.txt"
							}
			}
list.Set("Vehicles", "subaru_outback_zero_lw", V)
