
-----------------------------------------------------
local V = {
			Name = "Dodge Charger R/T 2015 Undercover", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/dodge_charger_2015_undercover.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dodge_charger_2015_police.txt"
							}
			}
list.Set("Vehicles", "dodge_charger_2015_undercover_lw", V)

