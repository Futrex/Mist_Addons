
-----------------------------------------------------
local V = {
			Name = "Dodge Monaco Police", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable monaco by LoneWolfie",
			Model = "models/LoneWolfie/dodge_monaco_police.mdl",
		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dodge_monaco.txt"
							}
			}
list.Set("Vehicles", "dodge_monaco_police_lw", V)
