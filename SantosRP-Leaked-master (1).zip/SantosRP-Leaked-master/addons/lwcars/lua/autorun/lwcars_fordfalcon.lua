
-----------------------------------------------------
local V = {
			Name = "Ford XB Falcon GT", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable lancia_037_stradale by LoneWolfie",
			Model = "models/LoneWolfie/ford_falcon_xb.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_falcon_xb.txt"
							}
			}
list.Set("Vehicles", "ford_falcon_xb_lw", V)
