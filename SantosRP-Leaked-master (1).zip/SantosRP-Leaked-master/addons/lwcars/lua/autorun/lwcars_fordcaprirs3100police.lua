
-----------------------------------------------------
local V = {
			Name = "Ford Capri Police", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable ford_capri_rs3100 by LoneWolfie",
			Model = "models/LoneWolfie/ford_capri_rs3100_police.mdl",
																				
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_capri_rs3100.txt"
							}
			}
list.Set("Vehicles", "ford_capri_rs3100_police_lw", V)
