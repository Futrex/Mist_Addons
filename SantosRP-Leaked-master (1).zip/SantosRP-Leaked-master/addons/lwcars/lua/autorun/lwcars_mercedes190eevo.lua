
-----------------------------------------------------
local V = {
			Name = "Mercedes 190E Evolution II", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable mercedes_190e_evo by LoneWolfie",
			Model = "models/LoneWolfie/mercedes_190e_evo.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/mercedes_190e_evo.txt"
							}
			}
list.Set("Vehicles", "mercedes_190e_evo_lw", V)
