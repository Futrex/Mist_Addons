
-----------------------------------------------------
local V = {
			Name = "Ferrari Risi Competizione F458 Italia", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fer458 by LoneWolfie",
			Model = "models/LoneWolfie/fer_458_compe.mdl",

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/fer_458_comp.txt"
							}
			}
list.Set("Vehicles", "fer458comp", V)

