
-----------------------------------------------------
local V = {
			Name = "Ferrari 458 Italia", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/ferrari_458.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ferrari_458.txt"
							}
			}
list.Set("Vehicles", "ferrari_458_lw", V)
