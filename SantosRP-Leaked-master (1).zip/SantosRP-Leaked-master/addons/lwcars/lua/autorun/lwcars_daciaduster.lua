
-----------------------------------------------------
local V = {
			Name = "Dacia Duster", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/dacia_duster.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dacia_duster.txt"
							}
			}
list.Set("Vehicles", "dacia_duster_lw", V)
