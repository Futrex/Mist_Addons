
-----------------------------------------------------
local V = {
			Name = "Renault Alpine A110 1600S", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/lonewolfie/renault_alpine.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/renault_alpine.txt"
							}
			}
list.Set("Vehicles", "renault_alpine_lw", V)

