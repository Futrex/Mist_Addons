
-----------------------------------------------------
local V = {
			Name = "Citroen DS3 WRC 2013", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable citroen_ds3_rally by LoneWolfie",
			Model = "models/LoneWolfie/citroen_ds3_rally.mdl",
				
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/citroen_ds3_rally.txt"
							}
			}
list.Set("Vehicles", "citroen_ds3_rally_lw", V)
