
-----------------------------------------------------
local V = {
			Name = "GMC Typhoon", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable typhoon by LoneWolfie",
			Model = "models/loneWolfie/gmc_typhoon.mdl",
	
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/gmc_typhoon.txt"
							}
			}
list.Set("Vehicles", "gmc_typhoon", V)
