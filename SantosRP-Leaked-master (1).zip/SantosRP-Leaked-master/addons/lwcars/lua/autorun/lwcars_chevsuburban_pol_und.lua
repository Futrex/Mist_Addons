
-----------------------------------------------------
local V = {
			Name = "Chevrolet Suburban Police Cruiser Undercover", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable Chevrolet Suburban GMT900 by LoneWolfie",
			Model = "models/LoneWolfie/chev_suburban_pol_und.mdl",

							KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/chev_suburban.txt"
							}
			}
list.Set("Vehicles", "chev_suburban_pol_und", V)
