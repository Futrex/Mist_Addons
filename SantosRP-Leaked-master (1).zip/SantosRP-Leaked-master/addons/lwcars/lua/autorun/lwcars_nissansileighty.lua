
-----------------------------------------------------
local V = {
			Name = "Nissan Sileighty", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable sileighty by LoneWolfie",
			Model = "models/LoneWolfie/nissan_sileighty.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/nissan_sileighty.txt"
							}
			}
list.Set("Vehicles", "nissan_sileighty_lw", V)
