
-----------------------------------------------------
local V = {
			Name = "Lancia 037 Stradale", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable lancia_037_stradale by LoneWolfie",
			Model = "models/LoneWolfie/lancia_037_stradale.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lancia_037_stradale.txt"
							}
			}
list.Set("Vehicles", "lancia_037_stradale_lw", V)
