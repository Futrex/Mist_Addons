
-----------------------------------------------------
local V = {
			Name = "Dodge Charger R/T 2015", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/dodge_charger_2015.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dodge_charger_2015.txt"
							}
			}
list.Set("Vehicles", "dodge_charger_2015_lw", V)

