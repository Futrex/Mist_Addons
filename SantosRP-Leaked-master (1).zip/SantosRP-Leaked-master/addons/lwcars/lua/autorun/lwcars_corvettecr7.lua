
-----------------------------------------------------
local V = {
			Name = "Chevrolet Corvette C7R GTE", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/corvette_c7r.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/corvette_c7r.txt"
							}
			}
list.Set("Vehicles", "corvette_c7r_lw", V)

