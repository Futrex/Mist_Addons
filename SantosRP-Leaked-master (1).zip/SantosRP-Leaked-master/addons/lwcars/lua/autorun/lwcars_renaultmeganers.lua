
-----------------------------------------------------
local V = {
			Name = "Renault Megane RS 250", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/lonewolfie/ren_meganers.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/ren_meganers.txt"
							}
			}
list.Set("Vehicles", "ren_meganers_lw", V)

