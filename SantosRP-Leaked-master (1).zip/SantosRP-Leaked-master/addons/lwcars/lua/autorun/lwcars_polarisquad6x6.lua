
-----------------------------------------------------
local V = {
			Name = "Polaris Quad 6x6", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable quad by LoneWolfie",
			Model = "models/LoneWolfie/polaris_6x6.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/polaris_6x6.txt"
							}
			}
list.Set("Vehicles", "polaris_6x6_lw", V)
