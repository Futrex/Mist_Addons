
-----------------------------------------------------
local V = {
			Name = "Porsche 911 RSR 74", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable porsche_911_rsr_74 by LoneWolfie",
			Model = "models/LoneWolfie/porsche_911_rsr_74.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/porsche_911_rsr_74.txt"
							}
			}
list.Set("Vehicles", "porsche_911_rsr_74_lw", V)
