
-----------------------------------------------------
local V = {
			Name = "GMC Yukon XL Denali", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable typhoon by LoneWolfie",
			Model = "models/loneWolfie/gmc_yukon.mdl",
		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/gmc_yukon.txt"
							}
			}
list.Set("Vehicles", "gmc_yukon_lw", V)
