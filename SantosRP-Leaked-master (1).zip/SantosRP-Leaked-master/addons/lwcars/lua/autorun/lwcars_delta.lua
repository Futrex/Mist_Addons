
-----------------------------------------------------
local V = {
			Name = "Lancia Delta HF Integrale", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable Lancia Delta by LoneWolfie",
			Model = "models/LoneWolfie/lan_delta_int.mdl",

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lan_delta.txt"
							}
			}
list.Set("Vehicles", "delta", V)
