
-----------------------------------------------------
local V = {
			Name = "Dodge Monaco", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable monaco by LoneWolfie",
			Model = "models/LoneWolfie/dodge_monaco.mdl",
		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dodge_monaco.txt"
							}
			}
list.Set("Vehicles", "dodge_monaco_lw", V)
