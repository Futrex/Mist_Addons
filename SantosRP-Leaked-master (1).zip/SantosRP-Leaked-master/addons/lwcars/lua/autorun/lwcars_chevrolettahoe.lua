
-----------------------------------------------------
local V = {
			Name = "Chevrolet Tahoe", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable tahoe by LoneWolfie",
			Model = "models/LoneWolfie/chev_tahoe.mdl",
							
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/chev_tahoe.txt"
				    }
			}
list.Set("Vehicles", "chev_tahoe_lw", V)
