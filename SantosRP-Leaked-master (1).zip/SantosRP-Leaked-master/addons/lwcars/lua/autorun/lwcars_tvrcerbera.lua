
-----------------------------------------------------
local V = {
			Name = "TVR Cerbera Speed 12", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/loneWolfie/tvr_cerbera12.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/tvr_cerbera12.txt"
							}
			}
list.Set("Vehicles", "tvr_cerbera12_lw", V)

