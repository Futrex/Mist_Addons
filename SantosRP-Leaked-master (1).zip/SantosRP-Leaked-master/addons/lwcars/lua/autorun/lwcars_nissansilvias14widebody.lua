
-----------------------------------------------------
local V = {
			Name = "Nissan 200SX S14 Widebody", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable UAZ 3907 6x6 by LoneWolfie",
			Model = "models/LoneWolfie/nissan_silvia_s14_wide.mdl",
		
													
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/nissan_silvia_s14_wide.txt"
							}
			}
list.Set("Vehicles", "nissan_silvia_s14_wide_lw", V)
