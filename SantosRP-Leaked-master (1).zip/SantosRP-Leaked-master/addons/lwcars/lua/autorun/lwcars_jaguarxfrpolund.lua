
-----------------------------------------------------
local V = {
			Name = "Jaguar XFR Special Escort Group", 
			Class = "prop_vehicle_jeep",
			Category = "LW Emergency Vehicles",
			Author = "LoneWolfie",
			Information = "Driveable jag xfr by LoneWolfie",
			Model = "models/LoneWolfie/jaguar_xfr_pol_und.mdl",
								
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/jag_xfr_pol.txt"
							}
			}
list.Set("Vehicles", "jag_xfr_pol_und", V)
