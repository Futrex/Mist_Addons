
-----------------------------------------------------
local V = {
			Name = "Hummer H1 Alpha Offroad Spec", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/hummer_h1_tc_offroad.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/hummer_h1_tc_offroad.txt"
							}
			}
list.Set("Vehicles", "hummer_h1_tc_offroad_lw", V)

