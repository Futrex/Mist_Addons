
-----------------------------------------------------
local V = {
			Name = "Aston Martin Cygnet", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable cygnet by LoneWolfie",
			Model = "models/LoneWolfie/astonmartin_cygnet.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/astonmartin_cygnet.txt"
							}
			}
list.Set("Vehicles", "astonmartin_cygnet_lw", V)
