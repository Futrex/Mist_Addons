
-----------------------------------------------------
local V = {
			Name = "Subaru Impreza WRX STI 2004", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/subaru_impreza_2004.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/subaru_impreza_2004.txt"
							}
			}
list.Set("Vehicles", "subaru_impreza_2004_lw", V)

