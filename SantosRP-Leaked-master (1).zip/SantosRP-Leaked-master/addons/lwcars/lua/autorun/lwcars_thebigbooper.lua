
-----------------------------------------------------
local V = {
			Name = "The Big Booper", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable bigbooper by LoneWolfie",
			Model = "models/LoneWolfie/thebigbooper.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/thebigbooper.txt"
							}
			}
list.Set("Vehicles", "thebigbooper_lw", V)
