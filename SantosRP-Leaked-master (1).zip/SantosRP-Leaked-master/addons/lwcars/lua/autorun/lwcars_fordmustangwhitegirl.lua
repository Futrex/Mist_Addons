
-----------------------------------------------------
local V = {
			Name = "Ford Mustang MkV Convertible", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/ford_mustang_whitegirl.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_mustang_whitegirl.txt"
							}
			}
list.Set("Vehicles", "ford_mustang_whitegirl_lw", V)

