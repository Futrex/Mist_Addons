
-----------------------------------------------------
local V = {
			Name = "Nissan Silvia Club Ks S13", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable wefewfewfw by LoneWolfie",
			Model = "models/LoneWolfie/nis_s13.mdl",
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/nis_s13.txt"
							}
			}
list.Set("Vehicles", "nis_s13", V)