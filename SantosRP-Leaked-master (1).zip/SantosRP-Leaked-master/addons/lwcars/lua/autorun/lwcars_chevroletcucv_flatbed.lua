
-----------------------------------------------------
local V = {
			Name = "Chevrolet CUCV M1008 Flatbed", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/chevrolet_cucv_flatbed.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/chevrolet_cucv_flatbed.txt"
							}
			}
list.Set("Vehicles", "chev_cucv_flatbed_lw", V)

