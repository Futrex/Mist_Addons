
-----------------------------------------------------
local V = {
			Name = "Nissan 200SX S14 Avant", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable UAZ 3907 6x6 by LoneWolfie",
			Model = "models/LoneWolfie/nissan_silvia_s14.mdl",
		
													
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/nissan_silvia_s14.txt"
							}
			}
list.Set("Vehicles", "nissan_silvia_s14_lw", V)
