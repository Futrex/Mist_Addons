
-----------------------------------------------------
local V = {
			Name = "Ferrari 312 1967", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "A 312 by Lonewolfie",
			Model = "models/lonewolfie/ferrari_312.mdl",		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/ferrari_312.txt"
							}
			}
list.Set("Vehicles", "ferrari_312_lw", V)

