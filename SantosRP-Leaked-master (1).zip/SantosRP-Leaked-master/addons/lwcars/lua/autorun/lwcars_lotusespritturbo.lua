
-----------------------------------------------------
local V = {
			Name = "Lotus Esprit Turbo [Type 82]", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable lotus_esprit_80 by LoneWolfie",
			Model = "models/LoneWolfie/lotus_esprit_80.mdl",
		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lotus_esprit_80.txt"
						}

			}
list.Set("Vehicles", "lotus_esprit_80_lw", V)
