
-----------------------------------------------------
local V = {
			Name = "TVR Sagaris", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable jag xfr by LoneWolfie",
			Model = "models/loneWolfie/tvr_sagaris.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/tvr_sagaris.txt"
							}
			}
list.Set("Vehicles", "tvr_sagaris_lw", V)
