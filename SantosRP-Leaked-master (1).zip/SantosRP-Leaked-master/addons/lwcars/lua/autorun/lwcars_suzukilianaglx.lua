
-----------------------------------------------------
local V = {
			Name = "Suzuki Liana GLX", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/suzuki_liana_glx.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/suzuki_liana_glx.txt"
							}
			}
list.Set("Vehicles", "suzuki_liana_glx_lw", V)
