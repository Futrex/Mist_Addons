
-----------------------------------------------------
local V = {
			Name = "Polaris Quad 4x4", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable quad by LoneWolfie",
			Model = "models/LoneWolfie/polaris_4x4.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/polaris_4x4.txt"
							}
			}
list.Set("Vehicles", "polaris_4x4_lw", V)
