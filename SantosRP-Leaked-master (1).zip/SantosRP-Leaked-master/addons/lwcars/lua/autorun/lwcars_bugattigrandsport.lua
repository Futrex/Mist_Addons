
-----------------------------------------------------
local V = {
			Name = "Bugatti Veyron 16.4 Grand Sport", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable the ferrari by LoneWolfie",
			Model = "models/loneWolfie/bugatti_veyron_grandsport.mdl",

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwCars/bugatti_veyron_grandsport.txt"
							}
			}
list.Set("Vehicles", "bugatti_veyron_grandsport_lw", V)
