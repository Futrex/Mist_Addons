
-----------------------------------------------------
local V = {
			Name = "McLaren F1 GTR 97", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/mclaren_f1_gtr97.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/mclaren_f1_gtr97.txt"
							}
			}
list.Set("Vehicles", "mclaren_f1_gtr97_lw", V)

