
-----------------------------------------------------
local V = {
			Name = "Nissan 200SX S14 Works Kit", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable UAZ 3907 6x6 by LoneWolfie",
			Model = "models/LoneWolfie/nissan_silvia_s14_works.mdl",
		
													
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/nissan_silvia_s14_works.txt"
							}
			}
list.Set("Vehicles", "nissan_silvia_s14_works_lw", V)
