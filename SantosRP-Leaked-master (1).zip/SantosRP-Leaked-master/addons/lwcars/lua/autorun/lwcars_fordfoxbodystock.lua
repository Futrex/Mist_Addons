
-----------------------------------------------------
local V = {
			Name = "Ford Cobra R 1993", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable ford_foxbody by LoneWolfie",
			Model = "models/LoneWolfie/ford_foxbody_stock.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_foxbody.txt"
							}
			}
list.Set("Vehicles", "ford_foxbody_stock_lw", V)
