
-----------------------------------------------------
local V = {
			Name = "GMC Savana News Van", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/gmc_savana_news.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/gmc_savana.txt"
							}
			}
list.Set("Vehicles", "gmc_savana_news_lw", V)

