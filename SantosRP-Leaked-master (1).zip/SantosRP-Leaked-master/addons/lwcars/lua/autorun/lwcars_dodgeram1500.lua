
-----------------------------------------------------
local V = {
			Name = "Dodge Ram 1500 Outdoorsman", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/dodge_ram_1500_outdoorsman.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/dodge_ram_1500_outdoorsman.txt"
							}
			}
list.Set("Vehicles", "dodge_ram_1500_outdoorsman_lw", V)
