
-----------------------------------------------------
local V = {
			Name = "Lamborghini Reventon", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/lam_reventon.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lam_reventon.txt"
							}
			}
list.Set("Vehicles", "lam_reventon_lw", V)

