
-----------------------------------------------------
local V = {
			Name = "TVR Tuscan S", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/loneWolfie/tvr_tuscans.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/tvr_tuscans.txt"
							}
			}
list.Set("Vehicles", "tvr_tuscans_lw", V)

