
-----------------------------------------------------
local V = {
			Name = "GMC Savana", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/gmc_savana.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/gmc_savana.txt"
							}
			}
list.Set("Vehicles", "gmc_savana_lw", V)

