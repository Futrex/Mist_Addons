
-----------------------------------------------------
local V = {
			Name = "Ferrari FF", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/ferrari_ff.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ferrari_ff.txt"
							}
			}
list.Set("Vehicles", "ferrari_ff_lw", V)
