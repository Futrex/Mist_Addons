
-----------------------------------------------------
local V = {
			Name = "Shelby Omni GLHS", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/shelby_glhs.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/shelby_glhs.txt"
							}
			}
list.Set("Vehicles", "shelby_glhs_lw", V)

