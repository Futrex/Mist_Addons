
-----------------------------------------------------
local V = {
			Name = "Subaru Impreza 22B STi Series I", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/subaru_22b.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/subaru_22b.txt"
							}
			}
list.Set("Vehicles", "subaru_22b_lw", V)

