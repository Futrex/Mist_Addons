
-----------------------------------------------------
local V = {
			Name = "Shelby GT500KR", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/shelby_gt500kr.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/shelby_gt500kr.txt"
							}
			}
list.Set("Vehicles", "shelby_gt500kr_lw", V)

