
-----------------------------------------------------
local V = {
			Name = "De Tomaso Pantera", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable detomaso_pantera by LoneWolfie",
			Model = "models/LoneWolfie/detomaso_pantera.mdl",

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/detomaso_pantera.txt"
							}
			}
list.Set("Vehicles", "detomaso_pantera_lw", V)
