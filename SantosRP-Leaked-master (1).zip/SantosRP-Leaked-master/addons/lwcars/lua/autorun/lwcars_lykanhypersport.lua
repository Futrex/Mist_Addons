
-----------------------------------------------------
local V = {
			Name = "W Motors Lykan Hypersport", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/lykan_hypersport.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lykan_hypersport.txt"
							}
			}
list.Set("Vehicles", "lykan_hypersport_lw", V)

