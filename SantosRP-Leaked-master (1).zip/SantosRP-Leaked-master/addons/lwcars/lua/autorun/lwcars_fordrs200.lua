
-----------------------------------------------------
local V = {
			Name = "Ford RS200", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/ford_rs200.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_rs200.txt"
							}
			}
list.Set("Vehicles", "ford_rs200_lw", V)

