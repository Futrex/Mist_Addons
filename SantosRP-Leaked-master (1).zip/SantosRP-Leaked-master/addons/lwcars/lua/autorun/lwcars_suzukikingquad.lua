
-----------------------------------------------------
local V = {
			Name = "Suzuki Kingquad", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable quad by LoneWolfie",
			Model = "models/LoneWolfie/suzuki_kingquad.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/suzuki_kingquad.txt"
							}
			}
list.Set("Vehicles", "suzuki_kingquad_lw", V)
