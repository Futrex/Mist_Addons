
-----------------------------------------------------
local V = {
			Name = "Morgan 3 Wheeler", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable morgan_3wheeler by LoneWolfie",
			Model = "models/LoneWolfie/morgan_3wheeler.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/morgan_3wheeler.txt"
							}
			}
list.Set("Vehicles", "morgan_3wheeler_lw", V)
