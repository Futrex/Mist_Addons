
-----------------------------------------------------
local V = {
			Name = "Mercedes Benz C63 AMG Black Series Aerodynamic Package", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable Mercedes-Benz C63 by LoneWolfie",
			Model = "models/LoneWolfie/mer_c63_amg.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/mer_c63_amg.txt"
							}
			}
list.Set("Vehicles", "mer_c63", V)
