
-----------------------------------------------------
local V = {
			Name = "Jaguar XFR", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable jag xfr by LoneWolfie",
			Model = "models/LoneWolfie/jaguar_xfr.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/jag_xfr.txt"
							}
			}
list.Set("Vehicles", "jag_xfr", V)
