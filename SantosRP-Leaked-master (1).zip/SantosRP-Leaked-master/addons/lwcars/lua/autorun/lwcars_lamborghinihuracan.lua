
-----------------------------------------------------
local V = {
			Name = "Lamborghini Huracan LP 610-4", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable lam_huracan by LoneWolfie",
			Model = "models/LoneWolfie/lam_huracan.mdl",

										
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lam_huracan.txt"
							}
			}
list.Set("Vehicles", "lam_huracan_lw", V)
