
-----------------------------------------------------
local V = {
			Name = "Renault 5 Turbo", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/lonewolfie/ren_5turbo.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/lwcars/ren_5turbo.txt"
							}
			}
list.Set("Vehicles", "ren_5turbo_lw", V)

