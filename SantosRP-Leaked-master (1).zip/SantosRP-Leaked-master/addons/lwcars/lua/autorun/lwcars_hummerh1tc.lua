
-----------------------------------------------------
local V = {
			Name = "Hummer H1 Alpha", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/hummer_h1_tc.mdl",
					
			KeyValues = {
	
							vehiclescript	=	"scripts/vehicles/LWCars/hummer_h1_tc.txt"
				     }
			}
list.Set("Vehicles", "hummer_h1_tc_lw", V)

