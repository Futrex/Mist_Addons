
-----------------------------------------------------
local V = {
			Name = "Lotus Exige S Roadster", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable lotus by LoneWolfie",
			Model = "models/LoneWolfie/lotus_exiges_roadster.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/lotus_exiges_roadster.txt"
							}
			}
list.Set("Vehicles", "lotus_exiges_roadster_lw", V)