
-----------------------------------------------------
local V = {
			Name = "Ford Capri RS3100 MK1", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable ford_capri_rs3100 by LoneWolfie",
			Model = "models/LoneWolfie/ford_capri_rs3100.mdl",
																				//Vehicle Controller
			
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ford_capri_rs3100.txt"
							}
			}
list.Set("Vehicles", "ford_capri_rs3100_lw", V)
