
-----------------------------------------------------
local V = {
			Name = "Subaru BRZ", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/subaru_brz.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/subaru_brz.txt"
							}
			}
list.Set("Vehicles", "subaru_brz_lw", V)

