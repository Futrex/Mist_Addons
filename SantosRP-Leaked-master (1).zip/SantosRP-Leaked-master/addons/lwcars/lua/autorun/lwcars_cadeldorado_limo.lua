
-----------------------------------------------------
local V = {
			Name = "Cadillac Eldorado Limo", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable Cadillac Eldorado Biarritz Convertible Limo by LoneWolfie",
			Model = "models/LoneWolfie/cad_eldorado_limo.mdl",

			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/cad_eldorado_limo.txt"
							}
			}
list.Set("Vehicles", "cad_eldorado_limo", V)
