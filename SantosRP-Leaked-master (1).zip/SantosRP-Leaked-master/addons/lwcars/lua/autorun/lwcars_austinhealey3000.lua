
-----------------------------------------------------
local V = {
			Name = "Austin Healey 3000 MkIII", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable fef by LoneWolfie",
			Model = "models/LoneWolfie/austin_healey_3000.mdl",
					
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/austin_healey_3000.txt"
							}
			}
list.Set("Vehicles", "austin_healey_3000_lw", V)

