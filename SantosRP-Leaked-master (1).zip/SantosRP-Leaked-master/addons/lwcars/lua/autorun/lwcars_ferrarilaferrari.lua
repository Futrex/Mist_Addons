
-----------------------------------------------------
local V = {
			Name = "Ferrari LaFerrari", 
			Class = "prop_vehicle_jeep",
			Category = "LW Cars",
			Author = "LoneWolfie",
			Information = "Driveable the ferrari by LoneWolfie",
			Model = "models/LoneWolfie/ferrari_laferrari.mdl",
		
			KeyValues = {
							vehiclescript	=	"scripts/vehicles/LWCars/ferrari_laferrari.txt"
							}
			}
list.Set("Vehicles", "ferrari_laferrari_lw", V)

