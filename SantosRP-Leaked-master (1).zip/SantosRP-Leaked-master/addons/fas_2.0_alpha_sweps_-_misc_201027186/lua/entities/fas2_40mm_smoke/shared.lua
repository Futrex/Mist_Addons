
-----------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Launcher smoke grenade"
ENT.Author = "L337N008"
ENT.Information = [[A 40MM smoke grenade launched from an underslung grenade launcher M203
Used to create temporary smoke cloud cover
Hit target receives damage dependent on projectile speed
No blast damage]]
ENT.Spawnable = false
ENT.AdminSpawnable = false 
