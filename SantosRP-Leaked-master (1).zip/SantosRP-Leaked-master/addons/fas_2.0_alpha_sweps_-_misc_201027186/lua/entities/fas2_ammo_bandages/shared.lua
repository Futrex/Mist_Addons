
-----------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "Bandages"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Medical"
ENT.AmmoType = "Bandages"
ENT.Amount = 10