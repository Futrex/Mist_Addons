
-----------------------------------------------------
ENT.Type = "anim"
ENT.Base = "base_entity"
ENT.PrintName = "40MM HE Ammo"
ENT.Author = "Spy"
ENT.Spawnable = true
ENT.AdminSpawnable = true 
ENT.Category = "FA:S 2.0 Ammo"
ENT.AmmoType = "40MM HE"
ENT.Amount = 10