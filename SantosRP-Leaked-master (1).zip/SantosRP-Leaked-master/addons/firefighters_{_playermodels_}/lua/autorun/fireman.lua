
-----------------------------------------------------
player_manager.AddValidModel( "fireman_1", "models/player/portal/Male_02_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_1", "models/player/portal/Male_02_fireman.mdl" )

player_manager.AddValidModel( "fireman_2", "models/player/portal/Male_04_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_2", "models/player/portal/Male_04_fireman.mdl" )

player_manager.AddValidModel( "fireman_3", "models/player/portal/Male_05_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_3", "models/player/portal/Male_05_fireman.mdl" )

player_manager.AddValidModel( "fireman_4", "models/player/portal/Male_06_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_4", "models/player/portal/Male_06_fireman.mdl" )

player_manager.AddValidModel( "fireman_5", "models/player/portal/Male_07_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_5", "models/player/portal/Male_07_fireman.mdl" )

player_manager.AddValidModel( "fireman_6", "models/player/portal/Male_08_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_6", "models/player/portal/Male_08_fireman.mdl" )

player_manager.AddValidModel( "fireman_7", "models/player/portal/Male_09_fireman.mdl" )
list.Set( "PlayerOptionsModel", "fireman_7", "models/player/portal/Male_09_fireman.mdl" )
